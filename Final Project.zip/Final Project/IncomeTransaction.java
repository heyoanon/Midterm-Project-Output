public class IncomeTransaction extends Transaction {
    public IncomeTransaction(double amount, String date, String description, Category category) {
        super(amount, date, description, category);
    }

    @Override
    public String getTransactionType() {
        return "Income";
    }
}