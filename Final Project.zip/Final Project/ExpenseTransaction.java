public class ExpenseTransaction extends Transaction {
    public ExpenseTransaction(double amount, String date, String description, Category category) {
        super(amount, date, description, category);
    }

    @Override
    public String getTransactionType() {
        return "Expense";
    }
}