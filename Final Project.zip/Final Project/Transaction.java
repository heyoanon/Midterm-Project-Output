public abstract class Transaction {
    double amount;
    private String date;
    private String description;
    private Category category;

    public Transaction(double amount, String date, String description, Category category) {
        this.amount = amount;
        this.date = date;
        this.description = description;
        this.category = category;
    }

    public double getAmount() {
        return amount;
    }

    public String getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }
    
    public abstract String getTransactionType();
}
