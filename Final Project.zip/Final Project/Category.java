public class Category {} {
    private String categoryName;
    private double monthlyBudgetLimit;

    public Category(String categoryName, double monthlyBudgetLimit) {
        this.categoryName = categoryName;
        this.monthlyBudgetLimit = monthlyBudgetLimit;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public double getMonthlyBudgetLimit() {
        return monthlyBudgetLimit;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public void setMonthlyBudgetLimit(double monthlyBudgetLimit) {
        this.monthlyBudgetLimit = monthlyBudgetLimit;
    }
}
