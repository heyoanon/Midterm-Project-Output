public class User {
    private String userId;
    private String name;
    private String email;

    public User(String userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
    
    public void updateProfile(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public String getFinancialSummary(List<Transaction> userTransactions) {
        double totalIncome = 0;
        double totalExpenses = 0;

        for (Transaction t : userTransactions) {
            if (t.getTransactionType().equals("income")) {
                totalIncome += t.getAmount();
            } else if (t.getTransactionType().equals("expense")) {
                totalExpenses += t.getAmount();
            }
        }

        return String.format(
            "=== Financial Summary for %s ===\n" +
            "Total Income: $%.2f\n" +
            "Total Expenses: $%.2f\n" +
            "Net Balance: $%.2f\n",
            this.name,
            totalIncome,
            totalExpenses,
            (totalIncome - totalExpenses)
        );
    }
}